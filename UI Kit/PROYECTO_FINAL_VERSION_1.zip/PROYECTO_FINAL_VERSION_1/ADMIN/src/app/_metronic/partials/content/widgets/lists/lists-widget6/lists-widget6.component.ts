import { Component } from '@angular/core';

@Component({
  selector: 'app-lists-widget6',
  templateUrl: './lists-widget6.component.html',
})
export class ListsWidget6Component {
  constructor() {}
}
