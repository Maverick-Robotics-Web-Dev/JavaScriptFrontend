import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-anidado-variations',
  templateUrl: './delete-anidado-variations.component.html',
  styleUrls: ['./delete-anidado-variations.component.scss']
})
export class DeleteAnidadoVariationsComponent {

}
