// #fake-start#
export { AuthHTTPService } from './fake/auth-fake-http.service'; // You have to comment this, when your real back-end is done
// #fake-end#

// #real-start#
// export { AuthHTTPService } from './auth-http.service'; // You have to uncomment this, when your real back-end is done
// #real-end#
